#!/usr/bin/env python

import rospy
from geometry_msgs.msg import PoseStamped
from mavros_msgs.msg import State
from mavros_msgs.srv import CommandBool, SetMode, CommandTOL
import time

class LeaderDrone:
    def __init__(self):
        rospy.init_node('leader_drone_node', anonymous=True)

        # Leader Drone (d1) Subscribers and Publishers
        self.state_sub1 = rospy.Subscriber('/d1/mavros/state', State, self.state_cb1)
        self.local_pos_pub1 = rospy.Publisher('/d1/mavros/setpoint_position/local', PoseStamped, queue_size=10)
        self.arming_client1 = rospy.ServiceProxy('/d1/mavros/cmd/arming', CommandBool)
        self.set_mode_client1 = rospy.ServiceProxy('/d1/mavros/set_mode', SetMode)
        self.set_takeoff_client1 = rospy.ServiceProxy('/d1/mavros/cmd/takeoff', CommandTOL)

        # Follower Drone 1 (d2) Subscribers and Publishers
        self.state_sub2 = rospy.Subscriber('/d2/mavros/state', State, self.state_cb2)
        self.local_pos_pub2 = rospy.Publisher('/d2/mavros/setpoint_position/local', PoseStamped, queue_size=10)
        self.arming_client2 = rospy.ServiceProxy('/d2/mavros/cmd/arming', CommandBool)
        self.set_mode_client2 = rospy.ServiceProxy('/d2/mavros/set_mode', SetMode)
        self.set_takeoff_client2 = rospy.ServiceProxy('/d2/mavros/cmd/takeoff', CommandTOL)

        # Follower Drone 2 (d3) Subscribers and Publishers
        self.state_sub3 = rospy.Subscriber('/d3/mavros/state', State, self.state_cb3)
        self.local_pos_pub3 = rospy.Publisher('/d3/mavros/setpoint_position/local', PoseStamped, queue_size=10)
        self.arming_client3 = rospy.ServiceProxy('/d3/mavros/cmd/arming', CommandBool)
        self.set_mode_client3 = rospy.ServiceProxy('/d3/mavros/set_mode', SetMode)
        self.set_takeoff_client3 = rospy.ServiceProxy('/d3/mavros/cmd/takeoff', CommandTOL)

        # State placeholders
        self.current_state1 = State()
        self.current_state2 = State()
        self.current_state3 = State()

        # Pose for the leader drone
        self.current_pose1 = PoseStamped()

        # Target positions
        self.target_position1 = PoseStamped()
        self.target_position2 = PoseStamped()
        self.target_position3 = PoseStamped()

        self.takeoff_complete = False
        self.rate = rospy.Rate(20)

        # Subscriber to leader's position
        self.pose_sub1 = rospy.Subscriber('/d1/mavros/local_position/pose', PoseStamped, self.pose_cb1)

        # Offsets for follower drones
        self.follower_offset_x2 = -2.0  # 2 meters behind the leader for drone 2
        self.follower_offset_x3 = -4.0  # 4 meters behind the leader for drone 3

    def state_cb1(self, state):
        self.current_state1 = state

    def state_cb2(self, state):
        self.current_state2 = state

    def state_cb3(self, state):
        self.current_state3 = state

    def arm_and_takeoff(self):
        # Set mode to GUIDED and arm the drones
        while not (self.current_state1.mode == "GUIDED" and self.current_state2.mode == "GUIDED" and self.current_state3.mode == "GUIDED"):
            self.set_mode_client1(custom_mode="GUIDED")
            self.set_mode_client2(custom_mode="GUIDED")
            self.set_mode_client3(custom_mode="GUIDED")
            self.rate.sleep()

        while not (self.current_state1.armed and self.current_state2.armed and self.current_state3.armed):
            self.arming_client1(True)
            self.arming_client2(True)
            self.arming_client3(True)
            self.rate.sleep()

        # Takeoff to altitude 5m
        self.set_takeoff_client1(altitude=5.0)
        self.set_takeoff_client2(altitude=5.0)
        self.set_takeoff_client3(altitude=5.0)

        rospy.loginfo("Leader and follower drones taking off to 5m altitude")

        # Wait for takeoff completion
        while self.current_pose1.pose.position.z < 4.9:
            rospy.loginfo("Waiting for leader to reach takeoff altitude...")
            self.rate.sleep()

        self.takeoff_complete = True
        rospy.loginfo("Drones have reached takeoff altitude")

    def pose_cb1(self, pose):
        # Update leader's current pose
        self.current_pose1 = pose

        if self.takeoff_complete:
            # Set the followers to follow the leader with offsets
            self.target_position2.pose.position.x = self.current_pose1.pose.position.x + self.follower_offset_x2
            self.target_position2.pose.position.y = self.current_pose1.pose.position.y
            self.target_position2.pose.position.z = self.current_pose1.pose.position.z
            self.local_pos_pub2.publish(self.target_position2)

            self.target_position3.pose.position.x = self.current_pose1.pose.position.x + self.follower_offset_x3
            self.target_position3.pose.position.y = self.current_pose1.pose.position.y
            self.target_position3.pose.position.z = self.current_pose1.pose.position.z
            self.local_pos_pub3.publish(self.target_position3)

    def send_position1(self, x, y, z):
        # Move leader drone to a new position
        self.target_position1.pose.position.x = x
        self.target_position1.pose.position.y = y
        self.target_position1.pose.position.z = z
        self.local_pos_pub1.publish(self.target_position1)

        rospy.loginfo(f"Leader drone moving to position: {x}, {y}, {z}")

if __name__ == '__main__':
    leader = LeaderDrone()
    leader.arm_and_takeoff()

    # Move leader drone to various positions
    time.sleep(10)
    leader.send_position1(4, 1, 5)  # Move to (4, 1, 5)
    time.sleep(10)
    leader.send_position1(1, 8, 5)  # Move to (1, 8, 5)
    time.sleep(10)
    leader.send_position1(8, 6, 7)  # Move to (8, 6, 7)
    time.sleep(10)
    leader.send_position1(0, 0, 5)  # Move back to (0, 0, 5)

    rospy.spin()
